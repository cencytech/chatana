<?php include('modal.php'); ?>

  <!-- Main Footer -- >
  <footer class="main-footer"> 
    <div class="pull-right hidden-xs">
      Anything you want
    </div> 
    <strong>Copyright &copy; 2018 <a href="#">Company</a>.</strong> All rights reserved.
  </footer>

	<!-- Control Sidebar -->
	<?php #include "pages/sidebar-right-tabpane.php" ?>
	<!-- /.control-sidebar -->
	<div class="control-sidebar-bg"></div>


</div><!-- ./wrapper -->

<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. - ->
	 
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 - ->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick - ->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- Sparkline - ->
<script src="bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  - ->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -- >
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -- >
<script src="bower_components/chart.js/Chart.js"></script>
 -->
</body>
</html>