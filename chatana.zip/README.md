# About Chatana
Chatana is a mobile app for smart-phones that helps you to connect and monitor farm reports using Chatana smartphone application. 
This app ensures you keep-up-to-date information, monitoring and status updates of live operation as well as sending content from your farm supervisor(s). 

# What is Chatana?
"Chat to Ana`s" + "Katana - Japanese sword" Fast-blade for connecting into multiple users can saved your time and chillax >_<
