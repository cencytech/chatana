
	<form method="POST" action="image_upload.php" enctype="multipart/form-data">
		<input type="file" class="form-control" name="img_location">
		<button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal-default">
            Upload
		</button>
	</form>
