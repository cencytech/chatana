 
<!-- Edit User -->
    <div class="modal #fade" id="edit_user" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Update My Profile</h4></center>
                </div>
				<div class="modal-body">
					<div class="container-fluid">
						
						<div class="form-group input-group">
							<span class="input-group-addon" >Nickname:</span>
							<input type="text" class="form-control" id="user_user">
						</div>

						<div class="form-group input-group">
							<span class="input-group-addon" >Mobile Number:</span>
							<input type="text" class="form-control" id="user_name">
						</div>

						<div class="form-group input-group">
							<span class="input-group-addon" >Password:</span>
							<input type="text" class="form-control" id="user_pass">
						</div>

					</div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="button" class="btn btn-success" id="confirm_update"><span class="glyphicon glyphicon-check"></span> Update</button>
				
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<!-- /.modal -->

