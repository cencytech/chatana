<?php 
$conn = new mysqli('localhost', 'root', '', 'sc_chat_system') or die(mysqli_error($conn));
?>