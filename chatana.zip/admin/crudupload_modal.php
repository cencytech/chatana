<!-- Add User -->
	<div class="modal #fade" id="upload" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					
                    <center><h4 class="modal-title" id="myModalLabel">Send Attachment</h4></center>
                </div>
				<div class="modal-body">
					<div class="container-fluid">
					<form>
						<div class="form-group input-group">
							<span class="input-group-addon" >Mobile Number:</span>
							<input type="number" class="form-control" id="uname" required>
						</div> 
					</div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="button" class="btn btn-primary" id="adduser"><span class="glyphicon glyphicon-check"></span> Add</button>
				</form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<!-- /.modal -->
 
